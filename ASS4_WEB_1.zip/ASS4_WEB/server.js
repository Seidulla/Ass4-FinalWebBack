const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const { MongoClient } = require('mongodb');
const path = require('path');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const app = express();
const jwt = require('jsonwebtoken'); 
const itemRoutes = require('./routes/items');
const axios = require('axios');
const port = 3000;

const username = 'Seidulla'; 
const accessToken = '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';

const uri = 'mongodb://localhost:27017'; 
const dbName = 'Final'; 
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });


app.use(session({
    secret: 'Secret',
    resave: false,
    saveUninitialized: false
  }));


mongoose.connect('mongodb://localhost:27017/Final', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch(error => {
        console.error('MongoDB connection error:', error);
    });

app.use(express.json());


app.use('/api/items', itemRoutes);
  
client.connect(err => {
    if (err) {
        console.error('Failed to connect to MongoDB:', err);
        return;
    }
    console.log('Connected to MongoDB');
    
    db = client.db(dbName);
});

//SIGNIT
process.on('SIGINT', () => {
    client.close().then(() => {
        console.log('MongoDB connection closed');
        process.exit(); 
    }).catch(err => {
        console.error('Error closing MongoDB connection:', err);
        process.exit(1); 
    });
});

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }))

app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.render('index', { user: req.session.user }); 
});

// REGISTER
app.get('/register', (req, res) => {
    res.render('register', { registrationSuccess: false });
});

app.post('/register', async (req, res) => {
    try {
        const hashedPassword = await bcrypt.hash(req.body.password, 10);
        const db = client.db(dbName);
        const role = req.body.username === 'Seidulla' ? 'admin' : 'user';
        await db.collection('users').insertOne({
            username: req.body.username,
            password: hashedPassword,
            email: req.body.email,
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            age: parseInt(req.body.age),
            country: req.body.country,
            gender: req.body.gender,
            role: role
        });
        await sendWelcomeEmail(req.body.email);
        res.render('register', { registrationSuccess: true });
    } catch (error) {
        console.error('Error during registration:', error);
        res.send('An error occurred during registration.');
    }
});


//LOGIN
app.get('/login', (req, res) => {
    res.render('login');
});

// Handle login form submission
app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        
        if (username === 'Seidulla' && password === 'secret') {
            res.redirect('/admin');
        } else if (username === 'Sultan' && password === '098765') {
            res.redirect('/user');
        } else {
            res.status(401).send('Invalid username or password');
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).send('An error occurred during login.');
    }
});

app.get('/admin', (req, res) => {
    res.render('admin', { username: req.user ? req.user.username : 'Seidulla Admin' });
});

app.get('/user', (req, res) => {
    res.render('user', { username: req.user ? req.user.username : 'Sultan' });
});

axios.get(`https://api.github.com/users/${username}/repos`, {
    headers: {
        Authorization: `token ${accessToken}`
    }
})
.then(response => {
    const repositories = response.data;

    const repositoryNames = repositories.map(repo => repo.name);
    const starsCount = repositories.map(repo => repo.stargazers_count);
    const forksCount = repositories.map(repo => repo.forks_count);
    const issuesCount = repositories.map(repo => repo.open_issues_count);

    console.log('Repository Names:', repositoryNames);
    console.log('Stars Count:', starsCount);
    console.log('Forks Count:', forksCount);
    console.log('Issues Count:', issuesCount);

  
})
.catch(error => {
    console.error('Error fetching repository data:', error);
});

async function getCryptoData() {
    try {
        const response = await axios.get('https://api.coingecko.com/api/v3/coins/bitcoin');

        const { data } = response;
        const { name, symbol, market_data } = data;
        const { current_price, market_cap } = market_data;

        console.log('Name:', name);
        console.log('Symbol:', symbol);
        console.log('Current Price:', current_price.usd);
        console.log('Market Cap:', market_cap.usd);
    } catch (error) {
        console.error('Error fetching cryptocurrency data:', error);
    }
}

getCryptoData();

async function getAPODData() {
    try {
        const response = await axios.get('https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY');

        const { data } = response;
        const { date, title, explanation, hdurl } = data;

        console.log('Date:', date);
        console.log('Title:', title);
        console.log('Explanation:', explanation);
        console.log('HD Image URL:', hdurl);
    } catch (error) {
        console.error('Error fetching NASA APOD data:', error);
    }
}


getAPODData();

const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    host: 'smtp.mail.ru',
    port: 465,
    secure: true, 
    auth: {
        user: 'example.sh7@mail.ru', 
        pass: 'zip14QGJuH8PsgLjg8vP' 
    }
});

async function sendWelcomeEmail(email) {
    try {
        let info = await transporter.sendMail({
            from: '"Seidulla Shalkharov" <example.sh7@mail.ru>',
            to: email, 
            subject: 'Welcome to Our Website!',
            text: 'Welcome to our website! Thank you for registering.', 
            html: '<b>Welcome to our website!</b><br><p>Thank you for registering.</p>' 
        });

        console.log('Message sent: %s', info.messageId);
    } catch (error) {
        console.error('Error sending welcome email:', error);
    }
}


app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
});